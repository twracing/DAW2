/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package com.mycompany.proyecto2;

import java.sql.*;
import java.util.Scanner;

public class Proyecto2 {

    public static void main(String[] args) {

        crearTabla();
        insertarIniciales();

        Scanner sc = new Scanner(System.in);
        String opcion;

        do {
            System.out.println("\n1) Listar futbolistas\n2) Añadir futbolista\n3) Borrar futbolista\n0) Salir");
            System.out.print("Opción: ");
            opcion = sc.nextLine();

            switch (opcion) {
                case "1" -> listar();
                case "2" -> añadir(sc);
                case "3" -> borrar(sc);
                case "0" -> System.out.println("Saliendo...");
                default -> System.out.println("Opción no válida");
            }
        } while (!opcion.equals("0"));
    }

    private static void crearTabla() {
        String sql = """
            CREATE TABLE IF NOT EXISTS futbolistas (
                id INT AUTO_INCREMENT PRIMARY KEY,
                nombre VARCHAR(100) UNIQUE
            );
        """;

        try (Connection c = Database.getConnection();
             Statement st = c.createStatement()) {
            st.execute(sql);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void insertarIniciales() {
        String[] iniciales = {
                "Lionel Messi",
                "Cristiano Ronaldo",
                "Kylian Mbappé",
                "Erling Haaland",
                "Kevin De Bruyne"
        };

        try (Connection c = Database.getConnection()) {
            for (String f : iniciales) {
                PreparedStatement ps =
                        c.prepareStatement("INSERT IGNORE INTO futbolistas (nombre) VALUES (?)");
                ps.setString(1, f);
                ps.executeUpdate();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void listar() {
        try (Connection c = Database.getConnection();
             Statement st = c.createStatement();
             ResultSet rs = st.executeQuery("SELECT nombre FROM futbolistas")) {

            System.out.println("Listado:");
            while (rs.next()) {
                System.out.println("- " + rs.getString("nombre"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void añadir(Scanner sc) {
        System.out.print("Nombre a añadir: ");
        String nombre = sc.nextLine();

        try (Connection c = Database.getConnection();
             PreparedStatement ps =
                     c.prepareStatement("INSERT INTO futbolistas (nombre) VALUES (?)")) {
            ps.setString(1, nombre);
            ps.executeUpdate();
        } catch (SQLException e) {
            System.out.println("No se pudo añadir (quizá ya existe).");
        }
    }

    private static void borrar(Scanner sc) {
        System.out.print("Nombre a borrar: ");
        String nombre = sc.nextLine();

        try (Connection c = Database.getConnection();
             PreparedStatement ps =
                     c.prepareStatement("DELETE FROM futbolistas WHERE nombre = ?")) {
            ps.setString(1, nombre);
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
